package gui;
import javax.swing.*;

public interface Component {
    public JPanel createComponents ();
}
