#include <iostream>
#include <cstring>
#include <cstdlib>

int sous_factoriel(int n) {
	/* A remplir */
}

int main(int argc, char *argv[]) {

	int n;

	if (argc < 2) {
		std::cout << "Syntax : ./subfact n" << std::endl;
		return -1;
	}
	
	n = atoi(argv[1]);
	
	std::cout << "n=" << n << std::endl;
	
	int result = sous_factoriel(n);
	std::cout << "sous-factoriel " << result << std::endl;
	
	return 0;	
}
